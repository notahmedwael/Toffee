/**
 * This class is responsible for showing available items to registered user.
 */

import java.util.Map;
import java.util.HashMap;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class Catalog {
    private final Map<String, Item> items = new HashMap<>();

    /**
     * Constructor Catalog that reads from file available items to be purchased.
     */
    public Catalog(){
        try {
            File myObj = new File("sweets.txt");
            Scanner myReader = new Scanner(myObj);

            while (myReader.hasNextLine()) {
                Item temp = new Item();
                String data = myReader.nextLine();
                temp.setItemName(data);
                data = myReader.nextLine();
                temp.setItemCategory(data);
                data = myReader.nextLine();
                temp.setItemDescription(data);
                data = myReader.nextLine();
                temp.setItemBrand(data);
                data = myReader.nextLine();
                temp.setItemPrice(Double.parseDouble(data));
                data = myReader.nextLine();
                temp.setItemDiscount(Double.parseDouble(data));
                data = myReader.nextLine();
                temp.setItemMeasure(data);
                items.put(temp.getItemName(), temp);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    /**
     * Method to display Catalog.
     */
    public void displayCatalog() {
        for (Map.Entry<String, Item> set : items.entrySet()) {
            System.out.println(set.getKey());
        }
    }

    /**
     * Method that searches the list and returns the item if found.
     * @param item taken as a parameter.
     * @return an object of type item.
     */
    public Item search(String item) {
        Item tempItem;
        tempItem = items.get(item);
        return tempItem;
    }
}