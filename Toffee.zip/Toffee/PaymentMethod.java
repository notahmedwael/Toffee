/**
 * Payment method interface that allows user to pay through different methods to choose from.
 * Implementing classes are expected to override the method processPayment.
 */
public interface PaymentMethod { void processPayment(double total);}