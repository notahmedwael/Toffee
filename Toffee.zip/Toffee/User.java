import java.util.ArrayList;
public class User {
    private String username;
    private String password;
    private int numItems;
    private double total;
    private boolean hasOrder = false;
    private final ArrayList<Item> cart = new ArrayList<>();
    private final ArrayList<Item> pastOrders = new ArrayList<>();
    public User(String username, String password){
        this.username = username;
        this.password = password;
        this.numItems = 0;
        this.total = 0.0;
    }
    public void setUserName(String username){
        this.username = username;
    }
    public void setPassword(String password){
        this.password=password;
    }
    public String getUserName(){
        return this.username;
    }
    public String getPassword(){
        return this.password;
    }
    public void addToCart(String itemName, double itemPrice){
        Item item = new Item(itemName,itemPrice);
        cart.add(item);
        numItems++;
    }
    public void removeFromCart(String itemName){
        boolean itemFound = false;
        for (Item item : cart){
            if (item.getItemName().equals(itemName)) {
                cart.remove(item);
                System.out.println("Item removed successfully.");
                itemFound = true;
                numItems--;
                break;
            }
        }
        if (!itemFound){
            System.out.println("Did not find the item!");
        }
    }
    public double getTotal() {
        for (Item item : cart){
            total += item.getItemPrice();
        }
        return total;
    }
    public void printCart() {
        if (numItems > 0) {
            System.out.println("Here is your cart: ");
            for (Item item : cart) {
                System.out.println("Item name: " + item.getItemName() + ", Item price: " + item.getItemPrice());
            }
        }
        else{
            System.out.println("Your cart is currently empty.");
        }
    }
    public void printPastOrders(){
        if (hasOrder){
            for (Item item : pastOrders) {
                System.out.println("Item name: " + item.getItemName() + "Item price: " + item.getItemPrice());
            }
        }
        else {
            System.out.println("You have no past orders.");
        }
    }
    public void moveToPastOrders(){
        hasOrder = true;
        pastOrders.addAll(cart);
    }
    public void deleteCart(){
        cart.clear();
        numItems = 0;
    }
}