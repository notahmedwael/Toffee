/**
 * This class
 */

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

/**

 User class represents a user of an online shopping system.

 It stores information about the user such as their name, email, password, phone number,

 as well as their current and past orders. Users can add, remove, and view items in their cart.
 */
public class User {

    private String name; // user's name
    private String email; // user's email address
    private String password; // user's password
    private final String phoneNumber; // user's phone number
    private int numItems; // number of items in the user's cart
    private double total; // total cost of items in the user's cart
    private boolean hasOrder = false; // whether the user has placed an order
    private final ArrayList<Item> cart = new ArrayList<>(); // list of items in the user's cart
    private final ArrayList<Item> pastOrders = new ArrayList<>(); // list of items from the user's past orders
    private ArrayList<String> pastOrdersNum = new ArrayList<>(); // list of order numbers from the user's past orders

    /**

     Constructs a User object with the given name, email, phone number, password,

     and list of past order numbers. It also reads in the user's past orders from the orders.txt file

     and stores them in the pastOrders and pastOrdersNum lists.

     @param name the user's name

     @param email the user's email address

     @param phoneNumber the user's phone number

     @param password the user's password

     @param pastOrdersNum list of past order numbers
     */
    public User(String name, String email, String phoneNumber, String password, ArrayList<String> pastOrdersNum) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.numItems = 0;
        this.total = 0.0;
        this.pastOrdersNum = pastOrdersNum;

        // Read the past orders from the orders.txt file and store them in the pastOrders and pastOrdersNum lists
        try (Scanner scanner = new Scanner(new File("orders.txt"))) {
            while (scanner.hasNextLine()) {
                String orderNumber = scanner.nextLine();
                ArrayList<Item> tempCart = new ArrayList<>();
                String itemName;
                if (pastOrdersNum.contains(orderNumber)) {
                    while (!(itemName = scanner.nextLine()).equals("|||")) {
                        double itemPrice = Double.parseDouble(scanner.nextLine());
                        addToTempCart(itemName, itemPrice, tempCart);
                    }
                    moveToTempPastOrders(tempCart);
                } else {
                    while (!(itemName = scanner.nextLine()).equals("|||")) {
                        Double itemPrice = Double.valueOf(scanner.nextLine());
                    }
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     Constructs a User object with the given name, email, phone number, and password.
     @param name the user's name
     @param email the user's email address
     @param phoneNumber the user's phone number
     @param password the user's password
     */
    public User(String name, String email, String phoneNumber, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.numItems = 0;
        this.total = 0.0;
    }

    /**
     Sets the name of the user.
     @param name the user's new name
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     Sets the password of the user.
     @param password the user's new password
     */
    public void setPassword(String password){
        this.password=password;
    }
    /**
     Sets the email of the user.
     @param email the user's new email
     */
    public void setEmail(String email){
        this.email=email;
    }
    /**

     Returns the name of the user.
     @return the name of the user
     */
    public String getName(){
        return this.name;
    }

    /**

     Returns the password of the user.
     @return the password of the user
     */
    public String getPassword(){
        return this.password;
    }

    /**

     Returns the email of the user.
     @return the email of the user
     */
    public String getEmail(){
        return this.email;
    }

    /**

     Returns the phone number of the user.
     @return the phone number of the user
     */
    public String getPhoneNumber(){
        return this.phoneNumber;
    }

    /**

     Adds an item to the user's cart.
     @param itemName the name of the item
     @param itemPrice the price of the item
     */
    public void addToCart(String itemName, double itemPrice){
        Item item = new Item(itemName,itemPrice);
        cart.add(item);
        numItems++;
    }

    /**

     Adds an item to a temporary cart.
     @param itemName the name of the item
     @param itemPrice the price of the item
     @param tempCart the temporary cart to add the item to
     */
    public void addToTempCart(String itemName, double itemPrice, ArrayList<Item> tempCart){
        Item item = new Item(itemName,itemPrice);
        tempCart.add(item);
    }

    /**

     Removes an item from the user's cart.
     @param itemName the name of the item to remove
     */
    public void removeFromCart(String itemName){
        boolean itemFound = false;
        for (Item item : cart){
            if (item.getItemName().equals(itemName)) {
                cart.remove(item);
                System.out.println("Item removed successfully.");
                itemFound = true;
                numItems--;
                break;
            }
        }
        if (!itemFound){
            System.out.println("Did not find the item!");
        }
    }

    /**

     Calculates the total price of items in the user's cart.
     @return the total price of items in the cart
     */
    public double getTotal() {
        for (Item item : cart){
            total += item.getItemPrice();
        }
        return total;
    }

    /**

     Prints the items in the user's cart.
     */
    public void printCart() {
        if (numItems > 0) {
            System.out.println("Here is your cart: ");
            for (Item item : cart) {
                System.out.println("Item name: " + item.getItemName() + ", Total price: " + item.getItemPrice());
            }
            System.out.println("\n\n\n");
        }
        else{
            System.out.println("Your cart is currently empty.");
        }
    }

    /**

     Prints the items in a temporary cart.
     @param tempCart the temporary cart to print
     @param orderNum the order number associated with the temporary cart
     */
    public void printTempCart(ArrayList<Item> tempCart, String orderNum) {
        System.out.println("Order " + orderNum);
            for (Item item : tempCart) {
                System.out.println("Item name: " + item.getItemName() + ", Total price: " + item.getItemPrice());
            }
            System.out.println("\n\n\n");
    }
    public void writeOrderNum(String email, String orderNum){
        try {
            // Open the file for reading
            File file = new File("users.txt");
            Scanner scanner = new Scanner(file);

            // Read the file line by line

            StringBuilder fileContent = new StringBuilder();
            boolean found = false;
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (line.trim().equals(email)) {
                    System.out.println("True");
                    found = true;
                    fileContent.append(line).append("\n");
                    fileContent.append(scanner.nextLine()).append("\n");
                    fileContent.append(scanner.nextLine()).append("\n");
                    fileContent.append(orderNum).append("\n"); // Append the order number
                } else {
                    fileContent.append(line).append("\n");
                }
            }
            scanner.close();

            if (!found) {
                // User not found, handle error
                System.out.println("User not found");
            } else {
                // Write the modified content back to the file
                FileWriter writer = new FileWriter(file, false); // Set append flag to false
                writer.write(fileContent.toString());
                writer.close();
            }
        } catch (IOException e) {
            System.out.println("An error occurred while writing users to file: " + e.getMessage());
        }
    }
    /**
     Prints user's past orders.
     */
    public void printPastOrders(){
        if (hasOrder){
            try (Scanner scanner = new Scanner(new File("orders.txt"))) {
                while (scanner.hasNextLine()) {
                    String orderNumber = scanner.nextLine();
                    ArrayList<Item> tempCart = new ArrayList<>();
                    String itemName;
                    if(pastOrdersNum.contains(orderNumber)) {
                        while (!(itemName = scanner.nextLine()).equals("|||")) {
                            double itemPrice = Double.parseDouble(scanner.nextLine());
                            addToTempCart(itemName, itemPrice, tempCart);
                        }
                        printTempCart(tempCart, orderNumber);
                    }else{
                        while (!(itemName = scanner.nextLine()).equals("|||")) {
                            Double itemPrice = Double.valueOf(scanner.nextLine());
                        }
                    }

                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        else {
            System.out.println("You have no past orders.");
        }
    }

    /**
     * Moves user order after completion to past orders item list to be shown in his profile.
     * @param orderNum is taken as a param to the method.
     */
    public void moveToPastOrders(int orderNum){
        hasOrder = true;
        pastOrders.addAll(cart);
        try {
            FileWriter writer = new FileWriter("orders.txt", true);
            // Write user information to the file
            orderNum++;
            writer.write(Integer.toString(orderNum) + "\n");
            for(Item item : cart){
                writer.write(item.getItemName() + "\n");
                writer.write(item.getItemPrice() + "\n");
            }
            writer.write("|||\n");
            writer.close();
        }catch (IOException e) {
            System.out.println("An error occurred while writing users to file: " + e.getMessage());
        }
        writeOrderNum(this.email, Integer.toString(orderNum));
        deleteCart();
    }

    /**
     * Method for a temp cart
     * @param tempCart is given to the method.
     */
    public void moveToTempPastOrders(ArrayList<Item> tempCart){
        hasOrder = true;
        pastOrders.addAll(tempCart);
    }

    /**
     * Clear cart after user finishes shopping and completes his order.
     */
    public void deleteCart(){
        cart.clear();
        numItems = 0;
    }
}