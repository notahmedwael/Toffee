import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.ArrayList;

public class Manager {
    public static void manage() {
        ArrayList<User> users = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            try {
                System.out.println("Hello dear user to our toffee store: ");
                System.out.println("What would you like to do: \n 1)Login. \n 2)Sign Up. \n 3)Discover our products. \n 0)Exit.");
                int choice = scanner.nextInt();
                String username, password;
                switch (choice) {
                    case 1 -> {
                        System.out.println("Enter username: ");
                        scanner.nextLine(); //consume newline character
                        username = scanner.nextLine();
                        System.out.println("Enter password: ");
                        password = scanner.nextLine();
                        boolean found = false;
                        for (User user : users) {
                            if (user.getUserName().equals(username) && user.getPassword().equals(password)) {
                                System.out.println("Login Successful");
                                found = true;
                                Login.loginDriver(user);
                                break;
                            }
                        }
                        if (!found) {
                            System.out.println("Unsuccessful login attempt!\nWrong username or password, Please try again.");
                        }
                    }
                    case 2 -> {
                        System.out.println("Enter username:");
                        scanner.nextLine(); //consume newline character
                        username = scanner.nextLine();
                        boolean userExists = false;
                        for (User user : users) {
                            if (user.getUserName().equals(username)) {
                                System.out.println("Username already exists, please choose a different username.");
                                userExists = true;
                                break;
                            }
                        }
                        if (!userExists) {
                            System.out.println("Enter password:");
                            password = scanner.nextLine();
                            users.add(new User(username, password));
                            System.out.println("Hooray We made an account together :)\nLogin to be able to order.");
                        }
                    }
                    case 3 -> {
                        Item availableItems = new Item();
                        availableItems.addItem("Candy", 14.5);
                        availableItems.addItem("Cream caramel", 20);
                        availableItems.addItem("Choco bars", 25);
                        availableItems.addItem("Choco bars", 25);
                        availableItems.removeItem("Choco bars");
                        availableItems.addItem("Mars", 15);
                        availableItems.addItem("Bounty", 15);
                        Item item1 = new Item();
                        item1.setItemName("M&M");
                        item1.setItemPrice(15);
                        availableItems.addItem(item1);
                        availableItems.printItemList();
                    }
                    case 0 -> {
                        System.out.println("Thanks for using the program :)");
                        System.exit(0);
                    }
                    default -> System.out.println("Invalid choice, Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input, Please enter a number.");
                scanner.nextLine(); // consume invalid input
            }
        }
    }
}