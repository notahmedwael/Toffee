/**
 *The Manager class is responsible for managing user accounts and handling the main menu of the program.
 *It reads user information from a file, allows users to register or log in, displays the catalog of products, and provides contact information.
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Manager {
    public static int orderNum = 0;
    static ArrayList<User> users = new ArrayList<>();
    public static Catalog catalog = new Catalog();
    /*
    public static String generateOTP() {
        int otpLength = 6;
        String digits = "0123456789";
        Random random = new Random();
        StringBuilder otp = new StringBuilder(otpLength);

        for (int i = 0; i < otpLength; i++) {
            otp.append(digits.charAt(random.nextInt(digits.length())));
        }

        return otp.toString();
    }
    */
    /**
     * Reads user information from a file and adds it to an ArrayList of User objects.
     * The file must be named "users.txt" and be formatted with each user's information on separate lines,
     * in the order of name, email, phone number, password, and past order numbers separated by "|||".
     * @param users An ArrayList of User objects to add the read user information to.
     */
    public static void readUsersFromFile(ArrayList<User> users) {
        try (Scanner scanner = new Scanner(new File("users.txt"))) {
            while (scanner.hasNextLine()) {
                String name = scanner.nextLine();
                String email = scanner.nextLine();
                String phoneNumber = scanner.nextLine();
                String password = scanner.nextLine();
                String tempOrder;
                ArrayList<String> pastOrdersNum = new ArrayList<>();
                while (!(tempOrder = scanner.nextLine()).equals("|||")) {
                    int tempOrderMax = Integer.parseInt(tempOrder);
                    if(orderNum < tempOrderMax){
                        orderNum = tempOrderMax;
                    }
                    pastOrdersNum.add(tempOrder);
                }
                User tempUser = new User(name, email, phoneNumber, password, pastOrdersNum);
                users.add(tempUser);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    /**
     * Allows users to register a new account by entering their name, email, phone number, and password.
     * Checks that the email address is not already in use by another user.
     * Writes the new user's information to a file named "users.txt".
     */
    public static void registerMenu() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Toffee Store!");
        System.out.println("Create account.");
        System.out.print("Your name: ");
        String name = scanner.nextLine();
        String email;

        while (true) {
            System.out.print("\nEmail: ");
            email = scanner.nextLine();
            boolean validEmail = true;
            for (User user : users) {
                if(Objects.equals(user.getEmail(), email)){
                    validEmail = false;
                    break;
                }
            }
            if (validEmail) {
                break;
            }
            System.out.println("This email address is used before. Please use another email address!");
        }

        System.out.print("\nPhone number: ");
        String phoneNumber = scanner.nextLine();

        System.out.print("\nPassword: ");
        String password = scanner.nextLine();

        User tempUser = new User(name, email, phoneNumber, password);
        users.add(tempUser);
        try {
            FileWriter writer = new FileWriter("users.txt", true);

            // Write user information to the file
            writer.write(name + "\n");
            writer.write(email + "\n");
            writer.write(phoneNumber + "\n");
            writer.write(password + "\n");
            writer.write("|||\n");
            writer.close();
        }catch (IOException e) {
            System.out.println("An error occurred while writing users to file: " + e.getMessage());
        }
        System.out.println("\nAccount created successfully!");
    }

    /**
     * manage static method responsible for managing the user interface.
     */
    public static void manage() {
        readUsersFromFile(users);
        Scanner scanner = new Scanner(System.in);
        while (true) {
            try {
                System.out.println("Hello dear user to our toffee store: ");
                System.out.println("What would you like to do: \n 1)Login. \n 2)Sign Up. \n 3)Discover our products. \n 4)Contact Us. \n 0)Exit.");
                int choice = scanner.nextInt();
                String email, password;
                switch (choice) {
                    case 1 -> {
                        //String otp = generateOTP();
                        System.out.println("Enter email: ");
                        scanner.nextLine(); //consume newline character
                        email = scanner.nextLine();
                        System.out.println("Enter password: ");
                        password = scanner.nextLine();
                        boolean found = false;
                        for (User user : users) {
                            if (user.getEmail().equals(email) && user.getPassword().equals(password)) {
                                System.out.println("Login Successful");
                                found = true;
                                //OTPManager otpManager = new OTPManager("otp-556@toffee-store.iam.gserviceaccount.com", "toffee-store-9335ed8128a3.p12");
                                //otpManager.sendEmailOTP(email,otp);
                                Login.loginDriver(user, orderNum);
                                break;
                            }
                        }
                        if (!found) {
                            System.out.println("Unsuccessful login attempt!\nWrong username or password, Please try again.");
                        }
                    }
                    case 2 -> {
                        registerMenu();
                            System.out.println("Hooray We made an account together :)\nLogin to be able to order.");
                        }

                    case 3 -> catalog.displayCatalog();
                    case 4 -> System.out.println("""
                            You can reach us here:
                            On facebook: fb.com/Toffee
                            On twitter: twitter.com/Toffee
                            On tiktok: tiktok.com/Toffee
                            Call us here: 01*********
                            """);
                    case 0 -> {
                        System.out.println("Thanks for using the program :)");
                        System.exit(0);
                    }
                    case 700 -> //Admin admin = new Admin();
                            Admin.printAllOrders();
                    default -> System.out.println("Invalid choice, Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input, Please enter a number.");
                scanner.nextLine(); // consume invalid input
            }
        }
    }
}