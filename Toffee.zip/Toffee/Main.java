/**
 This is toffee store backend system.
 Version: 1.0
 Last edited: 14/5/2023
 */

public class Main {

    /**
     * The main method launches the application by invoking the {@link Manager#manage()} method.
     *
     * @param args an array of command-line arguments
     */
    public static void main(String[] args) {
        Manager.manage();
    }
}