import java.util.Scanner;

public class Login {
    public static void loginDriver(User user) {
        Scanner scanner = new Scanner(System.in);
        int choice;
        String itemName, username, password;
        double itemPrice;
        while (true) {
            System.out.println("""
                    What would you like to do?
                     1)Add an item to your cart.
                     2)Remove an item from your cart.
                     3)Show cart.
                     4)Edit Profile.
                     5)Checkout.
                     6)Show past orders.
                     7)Logout
                    """);
            choice = scanner.nextInt();
            switch (choice){
                case 1 -> {
                    System.out.println("Please Enter item name:");
                    scanner.nextLine(); //consume newline character
                    itemName = scanner.nextLine();
                    System.out.println("Please enter the price:");
                    itemPrice = scanner.nextDouble();
                    user.addToCart(itemName, itemPrice);
                    System.out.println("Item added to cart successfully.");
                }
                case 2 -> {
                    System.out.println("Please enter item name to be removed:");
                    scanner.nextLine(); //consume newline character
                    itemName = scanner.nextLine();
                    user.removeFromCart(itemName);
                }
                case 3 ->
                    user.printCart();
                case 4 -> {
                    int userChoice;
                    System.out.println("""
                            What would you like to edit?
                            1)Username
                            2)Password
                            """);
                    scanner.nextLine(); //consume newline character
                    userChoice = scanner.nextInt();
                    if (userChoice == 1){
                        System.out.println("Enter new username: ");
                        username = scanner.nextLine();
                        user.setUserName(username);
                        System.out.println("Username changed successfully to: " + user.getUserName());
                    } else if (userChoice == 2){
                        System.out.println("Enter new password: ");
                        password = scanner.nextLine();
                        user.setPassword(password);
                        System.out.println("Password changed successfully.");
                    }
                    else{
                        System.out.println("Invalid choice.");
                    }
                }
                case 5 -> {
                    System.out.println("""
                    How would you like to receive your order:
                    1)COD(Cash on delivery).
                          """);
                    choice = scanner.nextInt();
                    if (choice == 1){
                        Checkout checkout = new Checkout();
                        COD cod = new COD();
                        checkout.checkoutDriver(user, cod);
                        user.moveToPastOrders();
                        user.deleteCart();
                    }
                    else {
                        System.out.println("Invalid payment method, Please try again.");
                    }
                }
                case 6->
                    user.printPastOrders();
                case 7 -> {
                    return;
                }
                default ->
                        System.out.println("Invalid choice, Please try again.");
                }
        }
    }
}