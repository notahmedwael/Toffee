/**
 * Method that takes user object and his payment method and passes this to process the payment
 * @see PaymentMethod
 */
public class Checkout {
    public void checkoutDriver(User user, PaymentMethod paymentMethod){
        paymentMethod.processPayment(user.getTotal());
    }
}