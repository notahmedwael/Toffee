/**
 * This class is what the catalog and user's cart are made of, a list of items.
 */

import java.util.ArrayList;

public class Item {
    /**
     * Item class attributes.
     */
    private String itemName;
    private String itemCategory;
    private String itemDescription;
    private String itemBrand;
    private double itemPrice;
    private double itemDiscount;
    private String itemMeasure;
    private static final ArrayList<Item> items = new ArrayList<>();

    /**
     * Default constructor.
     */
    public Item(){
        itemName = "Null";
        itemPrice = 0;
    }

    /**
     * Parameterized constructor.
     * @param itemName set by admin.
     * @param itemPrice set by admin.
     */
    public Item(String itemName, double itemPrice){
        this.itemName = itemName;
        this.itemPrice = itemPrice;
    }

    /**
     * Setter for itemName
     * @param itemName to be set.
     */
    public void setItemName(String itemName){
        this.itemName = itemName;
    }

    /**
     * Setter for itemCategory.
     * @param itemCategory to be set.
     */
    public void setItemCategory(String itemCategory){
        this.itemCategory = itemCategory;
    }

    /**
     * Setter for itemDescription.
     * @param itemDescription to be set.
     */
    public void setItemDescription(String itemDescription){
        this.itemDescription = itemDescription;
    }

    /**
     * Setter for itemBrand.
     * @param itemBrand to be set.
     */
    public void setItemBrand(String itemBrand){
        this.itemBrand = itemBrand;
    }

    /**
     * Setter for itemPrice.
     * @param itemPrice to be set.
     */
    public void setItemPrice(double itemPrice){
        this.itemPrice = itemPrice;
    }

    /**
     * Setter for Item Discount.
     * @param itemDiscount to be set.
     */
    public void setItemDiscount(double itemDiscount){
        this.itemDiscount = itemDiscount;
    }

    /**
     * Setter for itemMeasure.
     * @param itemMeasure to be set.
     */
    public void setItemMeasure(String itemMeasure){
        this.itemMeasure = itemMeasure;
    }

    /**
     * Method to display different item info.
     */
    public void displayItemInfo() {
        System.out.println("\nName: " + this.itemName);
        System.out.println("Category: " + this.itemCategory);
        System.out.println("Description: " + this.itemDescription);
        System.out.println("Brand: " + this.itemBrand);
        System.out.println("Price: " + this.itemPrice);
        System.out.println("Discount: " + this.itemDiscount);
        System.out.println("Sold by: " + this.itemMeasure + "\n");
    }

    /**
     * Getter for itemName.
     * @return itemName.
     */
    public String getItemName(){
        return itemName;
    }

    /**
     * Getter for itemPrice.
     * @return itemPrice.
     */
    public double getItemPrice(){
        return itemPrice;
    }

    /**
     * Getter for the items list.
     * @return items.
     */
    public static ArrayList<Item> getItems() {
        return items;
    }

    /**
     * Method that adds an item to the item list that takes an object of class Item.
     * @param item added to item list.
     */
    public void addItem(Item item) {
        items.add(item);
    }

    /**
     * Method that adds an item to the item list that takes two parameters itemName, and itemPrice to create an object
     * of class item to be added to the item list.
     * @param itemName as first parameter.
     * @param itemPrice as second parameter.
     */
    public void addItem(String itemName, double itemPrice){
        Item item = new Item(itemName,itemPrice);
        items.add(item);
    }

    /**
     * Method  that removes an item from the item list through searching by itemName.
     * @param itemName to search by.
     */
    /**
     * Method that removes an item from the item list by taking an object from class Item as a parameter and searching for
     * it to see if found and remove it.
     * @param itemName to search by.
     */
    public void removeItem(String itemName){
        boolean itemFound = false;
        for (Item item : items){
            if (item.getItemName().equals(itemName)) {
                items.remove(item);
                System.out.println("Item named " + getItemName() + " removed successfully.");
                itemFound = true;
                break;
            }
            }
        if (!itemFound){
            System.out.println("Did not find the item named "+ getItemName() +" .");
        }
        }

    /**
     * Method that prints the item list.
     */
    public void printItemList() {
        for (Item item : items) {
            System.out.println("Item name: " + item.getItemName() + ", Price: " + item.getItemPrice());
        }
    }
    }