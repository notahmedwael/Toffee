import java.util.ArrayList;

public class Item {
    private String itemName;
    private double itemPrice;
    private static final ArrayList<Item> items = new ArrayList<>();
    public Item(){
        itemName = "Null";
        itemPrice = 0;
    }
    public Item(String itemName, double itemPrice){
        this.itemName = itemName;
        this.itemPrice = itemPrice;
    }
    public void setItemName(String itemName){
        this.itemName = itemName;
    }
    public void setItemPrice(double itemPrice){
        this.itemPrice = itemPrice;
    }
    public String getItemName(){
        return itemName;
    }
    public double getItemPrice(){
        return itemPrice;
    }
    public static ArrayList<Item> getItems() {
        return items;
    }
    public void addItem(Item item) {
        items.add(item);
    }
    public void addItem(String itemName, double itemPrice){
        Item item = new Item(itemName,itemPrice);
        items.add(item);
    }
    public void removeItem(String itemName){
        boolean itemFound = false;
        for (Item item : items){
            if (item.getItemName().equals(itemName)) {
                items.remove(item);
                System.out.println("Item named " + getItemName() + " removed successfully.");
                itemFound = true;
                break;
            }
            }
        if (!itemFound){
            System.out.println("Did not find the item named "+ getItemName() +" .");
        }
        }
    public void printItemList() {
        for (Item item : items) {
            System.out.println("Item name: " + item.getItemName() + ", Price: " + item.getItemPrice());
        }
    }
    }