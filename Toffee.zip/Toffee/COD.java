/**
 * Cash on delivery class that implements PaymentMethod interface.
 */
public class COD implements PaymentMethod{
    /**
     * Method that takes the total value of the order and passes it as a parameter to the method to complete his order.
     * @param total taken from getTotal() method.
     */
    @Override
    public void processPayment(double total) {
        System.out.println("You successfully placed an order with a total of: " + total + " and payment will be through cash on payment.");
        //Code to actually process the payment using cash on delivery
        System.out.println("Payment processed successfully!");
    }
}